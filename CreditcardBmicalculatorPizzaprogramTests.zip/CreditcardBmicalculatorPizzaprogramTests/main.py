from random import choice as c
import random
import time



print("\n")
print(" Credit Card and Travel Conditional Tests ".center(60,"~"))
travel_destination = 'PARIS'
travel_items = ['luggage','credit card','fleece jacket',
'towels','sunscreen','journal','laptop','sunglasses']
credit_limit = 5000
credit_score = 740
#test for equality 
print('New message from Siri: Is your next travel destination PARIS? I predict True')
print (travel_destination == 'PARIS')
#inequality
print('New message from Siri: Is your next travel destination Pickering? I predict False')
print(travel_destination == 'Pickering')
#test for the lower() method
print('Is the .lower() method going to check for travel destination in lowercase? I predict True')
print(travel_destination.lower() == "paris") #travel_destination is in uppercase but the .lower() method converts the same string in variable travel_destination in lowercase before comparison is made

print("Is your credit limit 5000 dollars? I predict True!")
print (credit_limit == 5000) #numerical tests for equality
if credit_limit != 100000: #numerical tests for inequality.  
    print(f"I predict False! Tolu you need to make more money. You cannot travel to {travel_destination}!")
    print(credit_limit == 100000)
    

#Tests for greater than and less than, greater than or equal to, and less than and equal to.(comments are printed) 
print("I predit True because credit score is 740 'and' credit limit is 5000 which is less than 10000")
print(credit_score > 700 and (credit_limit < 10000))
print("I predit False because credit score is 740 which is less 800 ")
print (credit_score>= 800)
print("I predit False. Only one condition is met. Credit score is 740 but credit limit is 5000 not 10000. ")
print (credit_score <700 and credit_limit == 100000)

#tests that use and / or keyword operators
if travel_destination == "PARIS" and credit_limit > 10000: #going to print the next statement because only                                                 1 condition is met
    print(f"We are going to {travel_destination}")
else:
    print(f"Tolu you need to make more money. You cannot travel to {travel_destination}!")

if travel_destination == "PARIS" or credit_limit > 10000: #going to print the first statement because only                                                   1 condition is "needed" to be met
    print(f"You are going to {travel_destination}")
else:
    print(f"Tolu you need to make more money. You cannot travel to {travel_destination}!")

#test if the item is in travel_item list
if "credit card" in travel_items:
    print('Move to next check...')
if "life jacket" not in travel_items: #tests if the item is not in travel_item list 
    print('Travel check is incomplete: add life jacket')



print("\n")
print('Please enter weight and height to move to the next question')
print(" BMI (Metric) Calculator ".center(60,"~"))#Please enter weight and height to move to the next question
while True:
    user_weight = float(input ("Enter weight in kg: ")) #allows users input weight and height for BMI calculation inside the while loop
    user_height = float(input("Enter height in meters: "))
    print('{} / {}^2 = '.format(user_weight, user_height)) #shows users if inputed values are accurate before calc is done.
    bmi = round((float(user_weight/(user_height**2))),2)
    print (bmi)
    if bmi < 18.5:
        print(f"Calculated BMI is less than 18.5 therefore, you are Underweight.")
    if bmi >= 18.5 and bmi <= 24.9: #both conditions have to be met i.e betwwen greater than/equal to 18.5 "and"                   less than/equal to 24.9, The same goes for the following lines for the various BMI weight ranges..
        print(f"Calculated BMI is between 18.5 and 24.9, you are normal weight.")
    if bmi >= 25.0 and bmi <= 29.9:
        print(f"Calculated BMI is between 25.0 and 29.9, you are overweight.")
    if bmi >= 30.0 and bmi <= 34.9:
        print(f"Calculated BMI is between 30.0 and 34.9, you are Obese Class I.")
    if bmi >= 35.0 and bmi <= 39.9:
        print(f"Calculated BMI is between 35.0 and 39.9, you are Obese Class II.")
    if bmi >= 40.0:
        print(f"Calculated BMI is greater than 40, you are Obese Class III.")
    time.sleep (4) #allows user read bmi before moving on.
    break #if the program were to be in use constantly, there would be no need to break"""



print("\n")
print("Pizza Company Subscribers Program".center(60,"~"))
premium_list = ["archer","cherly","riley","raghav","figgis",]
candidates_list = premium_list[:] #copies items in members list to candidates list. not  neccesarily important to                copy entire list at once, a manual method works as well to copy "some" memebers from the premium_list into candidates_list
candidates_list.extend(["barry","krieger","woodhouse","marcus","tyler"]) #adds/extends the list "candidates_list" with the new inputs.
print(candidates_list)
#Makes sure old premium members do not get the premium invitation for the pizza program.
for candidates in candidates_list: 
    if candidates not in premium_list:
        print(f"{candidates.title()}, you are eligible to join the premium list, you would enjoy 30% off all online orders!")
    else:
        print(f"{candidates.title()}, you are already a member")



print("\n")
print(" QUESTION 3- Pizza Program ".center(60,"~"))
customer_name = input("Please enter name: ")
pizza_qty = int(input(f"How many pizzas do you want:\n"))
pizza_list = (input(
    "Enter preferred pizza sizes,you can input different sizes:\nsmall\nmedium\nlarge\n"
).split())
#.split allows multiple user input i.e. the various pizza style size they want, however if it is the same size more than once, it does not process order.
#i.e you cannot input any of the sizes twice, but order quantity of the different sizes can be more than 1.
if 'small' in pizza_list: #assigns price value to variable price with condiitonal input check in pizza_list
    price = 6.99
elif 'medium' in pizza_list:
    price = 8.99
elif 'large' in pizza_list:
    price = 10.99

subtotal = price * pizza_qty
tax = 13 / 100
total = subtotal + tax
if pizza_qty > 1 and (pizza_list.count("small") > 1 #permits user to order one size pizza by counting the number of occurence for one size style.
    or pizza_list.count("medium") > 1
    or pizza_list.count("large") > 1):
    print(f"Hmm.. sorry you can only order 1 size pizza")
elif "small" or "medium" or "large" in pizza_list:
    print(f"\nHello {customer_name}! Check out your order summary:\
    \nOrder items:{pizza_list}\nSubtotal: ${subtotal}\nTax(13%): {tax}\nOrder total: {round(total,2)}"
          )
time.sleep(2)



